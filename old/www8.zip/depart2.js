var d2 = new Array();
var d2 = new Array();
