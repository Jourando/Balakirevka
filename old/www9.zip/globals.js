urlStr='http://test2.ru/auth.php?';
datStr='http://test2.ru/writ.php?';