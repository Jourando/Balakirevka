<?php
echo "<html><body>";
echo "<table width=100% height=100%>\n<tr><td align=center>\n<h2 align=center>That is /home/test2.ru/www/index.php.</h2>\n</td></tr>\n</table>\n";
echo "<p>Just "."test</p>";
echo "</body></html>";
?>