urlStr = 'http:/'+'/test2.ru/auth.php?';
