var d1 = new Array();
d1[1]='1||w-22|15|наши|qwerty party|Питер||||||||||';
