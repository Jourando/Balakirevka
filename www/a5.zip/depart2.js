var d2 = new Array();
d2[1]='1||w 2222|12|||spb||||||||||';
