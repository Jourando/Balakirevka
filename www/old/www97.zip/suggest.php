<?php
// get the q parameter from URL
$fq = $_REQUEST["q"];
list($q, $m) = explode("___", $fq);
if ($m==0) {
	$xfile="dplaces0000.a";
} else {
	$xfile="dplaces0001.a";
}
$lines = file($xfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$i=0;
foreach($lines as $v) {
	list($a[], $b[])=explode("=>", $lines[$i]);
	$i++;
}
$hint = "";
// lookup all hints from array if $q is different from "" 
$divid=1;
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    foreach($a as $name) {
        if (stristr($q, substr($name, 0, $len))) {
            if ($hint === "") {
                $hint = '<div id=dv'.$divid.' OnClick="setSuggest(this.id)">'.$name.'</div>';
            } else {
				$divid=$divid+1;
                $hint .= '<div id=dv'.$divid.' OnClick="setSuggest(this.id)">'.$name.'</div>';
            }
        }
    }
}

// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "no suggestion" : $hint;
?>