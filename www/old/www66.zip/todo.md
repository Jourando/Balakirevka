TODO:

Для кнопки обновить: 
- обновить и продолжить сессию
- обновить и начать новую сессию
Сделать список идентефикаторов контролей 

сделать первичную создавалку дефолтных файлов

собрать тулзы в 1 менеджере +

- https://habrahabr.ru/post/245233/ excel
- https://habrahabr.ru/post/136540/ excel
- http://abcvg.com/9129-analog-json_decode-dlya-xml-na-php.html - xml
- http://yournet.kz/blog/php/phpexcel-formatirovanie-yacheek
- http://www.codenet.ru/webmast/php/Excel.php
- http://opennet.ru/base/dev/php_gen_excel.txt.html

Время и дату разбить на 2 колонки. Сделать проверку на мероприятия а) совпадающие по дате б) совпадающие по дате и времени в) совпадающие по дате, времени и месту
Время+дату не разрезаем на 2 поля! Делаем ограничение на ввод. Плюс 2 поля: начало мероприятия, конец мероприятия.

updater, logger, backman, backclean

сделать 2 строчный режим ввода
сделать вертикальный режим ввода

Ремейк 404