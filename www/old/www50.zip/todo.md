TODO:

Для кнопки обновить: 
- обновить и продолжить сессию
- обновить и начать новую сессию
Сделать список идентефикатороф контролей 

Объединить в writ2.php ф-ции Before + After
---''---- в main ф-ции отправки в ajax (before, replace, after и delete)

Сделать клинер для олдДата
Сделать менеджер откатов для олдДата

сделать импорт из csv, экспорт в xls

импорт докинуть туда же куда и экспорт - в rollback_man3.php но вывести отдельным пунктом

сделать первичную создавалку дефолтных файлов

собрать тулзы в 1 менеджере

- https://habrahabr.ru/post/245233/ excel
- https://habrahabr.ru/post/136540/ excel
- http://abcvg.com/9129-analog-json_decode-dlya-xml-na-php.html - xml
- http://yournet.kz/blog/php/phpexcel-formatirovanie-yacheek
- http://www.codenet.ru/webmast/php/Excel.php
- http://opennet.ru/base/dev/php_gen_excel.txt.html

Время и дату разбить на 2 колонки. Сделать проверку на мероприятия а) совпадающие по дате б) совпадающие по дате и времени в) совпадающие по дате, времени и месту

создать доку

сделать в файлах пометку о версии для апдейтера