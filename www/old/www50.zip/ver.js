var vi=10;
