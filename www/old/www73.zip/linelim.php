<?php
$linelimit=19;
?>