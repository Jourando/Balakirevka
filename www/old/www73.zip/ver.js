// v.10.a.1::verinfo revision
var vi=10;
