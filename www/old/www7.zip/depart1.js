var d1 = new Array();
d1[1]='1||w-22|10|наши|qwerty party|Питер||||||||||';
