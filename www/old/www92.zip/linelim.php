<?php
// v.10.a.1::linelimit revision
$linelimit=19;
$deplimit=12;
?>