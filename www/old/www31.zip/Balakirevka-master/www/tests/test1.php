<?php
echo "<html><head><title>STxt</title></head><body>\n<form action=writ.php method=post name=frm1>\n";
echo "<input type=text name=param> <input type=submit value=send>\n";
echo "</form>\n</body></html>\n";
echo "<!-- endfile -->";
?>