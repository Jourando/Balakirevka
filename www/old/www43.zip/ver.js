// verinfo
var vi=10;
