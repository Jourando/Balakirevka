<?php
// v.10.a.2::tab_header revision
function getContent($a1, $m1) {
$i=0;
foreach (glob("depart*.a") as $filename) {
    $fArray[$i]=$filename; 
	$j=0;
	if ($fArray[$i] !== "depart0000.a") {
		$lines[$i] = file($fArray[$i], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		$rx[$i]="<tr id=sec".$i."hdr class=T2><td id=hdr".$i." colspan=19 class=depHdr><div id=Atup".$i." class=TupShow OnClick='showhideSec(this.id,".$i.")'>⍙</div><div id=Adwn".$i." class=TdownHide OnClick='showhideSec(this.id,".$i.")'>⍢</div> Отдел: ".$m1[$i]."</td></tr>\r\n";
		echo $rx[$i];
		foreach($lines[$i] as $v) { // don't use 16, use array.lenght !!!
			list($n, $depart, $dStart, $dEnd, $vd, $acType, $acOwner, $acName, $acPlace, $oLvl, $oAud, $oSeer, $oPrt, $OOP, $hostHead, $hostLd, $hostOrg, $fin, $adInfo) = explode("|", $lines[$i][$j]);
			$rs[$i][$j]="<tr id=sec".$i."line".$j." class=T1 name=skip Onclick='modalEdit(\"sec".$i."line".$j."\")'><td id=s".$i."r".$j."c1>".$n."</td><td id=s".$i."r".$j."c2>".$depart."</td><td id=s".$i."r".$j."c3>".$dStart."</td><td id=s".$i."r".$j."c4>".$dEnd."</td><td id=s".$i."r".$j."c5>".$vd."</td><td id=s".$i."r".$j."c6>".$acType."</td><td id=s".$i."r".$j."c7>".$acOwner."</td><td id=s".$i."r".$j."c8>".$acName."</td><td id=s".$i."r".$j."c9>".$acPlace."</td><td id=s".$i."r".$j."c10>".$oLvl."</td>";
			$rs[$i][$j]=$rs[$i][$j]."<td id=s".$i."r".$j."c11>".$oAud."</td><td id=s".$i."r".$j."c12>".$oSeer."</td><td id=s".$i."r".$j."c13>".$oPrt."</td><td id=s".$i."r".$j."c14>".$OOP."</td><td id=s".$i."r".$j."c15>".$hostHead."</td><td id=s".$i."r".$j."c16>".$hostLd."</td><td id=s".$i."r".$j."c17>".$hostOrg."</td><td id=s".$i."r".$j."c18>".$fin."</td><td id=s".$i."r".$j."c19>".$adInfo."</td></tr>\r\n";
			echo $rs[$i][$j];
			$j=$j+1;
		}
	}
	$i=$i+1;
}
}
$cell1='<tr>';
$cell2='</tr>';
$cell3='</td>';
$th=file("tabhdrs.a");
$linearr [0] = array($cell1, $cell2, $cell3);
$linearr[1] = array(
	cell1 => array("cnt" => $th[0], "w" => "1", "h" => "2"),
	cell2 => array("cnt" => $th[1], "w" => "1", "h" => "2"),
	cell3 => array("cnt" => $th[2], "w" => "2", "h" => "1"),
	cell4 => array("cnt" => $th[3], "w" => "1", "h" => "2"),
	cell5 => array("cnt" => $th[4], "w" => "3", "h" => "1"),
	cell6 => array("cnt" => $th[5], "w" => "1", "h" => "2"),
	cell7 => array("cnt" => $th[6], "w" => "4", "h" => "1"),
	cell8 => array("cnt" => $th[7], "w" => "4", "h" => "1"),
	cell9 => array("cnt" => $th[8], "w" => "1", "h" => "2"),
	cell10 => array("cnt" => $th[9], "w" => "1", "h" => "2")
	);
$linearr[2] = array(
	cell1 => array("cnt" => $th[10], "w" => "1", "h" => "1"),
	cell2 => array("cnt" => $th[11], "w" => "1", "h" => "1"),
	cell3 => array("cnt" => $th[12], "w" => "1", "h" => "1"),
	cell4 => array("cnt" => $th[13], "w" => "1", "h" => "1"),
	cell5 => array("cnt" => $th[14], "w" => "1", "h" => "1"),
	cell6 => array("cnt" => $th[15], "w" => "1", "h" => "1"),
	cell7 => array("cnt" => $th[16], "w" => "1", "h" => "1"),
	cell8 => array("cnt" => $th[17], "w" => "1", "h" => "1"),
	cell9 => array("cnt" => $th[18], "w" => "1", "h" => "1"),
	cell10 => array("cnt" => $th[19], "w" => "1", "h" => "1"),
	cell11 => array("cnt" => $th[20], "w" => "1", "h" => "1"),
	cell12 => array("cnt" => $th[21], "w" => "1", "h" => "1"),
	cell13 => array("cnt" => $th[22], "w" => "1", "h" => "1")
	);
$tmpTR='';
for ($j=1; $j<count($linearr); $j++) {
	$tmpTR=$tmpTR.$cell1;
	for ($i=1; $i<count($linearr[$j])+1; $i++) {
		$tmpTD="<th";
		if ($linearr[$j]["cell".$i]["w"] !== '1') {$tmpTD=$tmpTD.' colspan='.$linearr[$j]["cell".$i]["w"];}
		if ($linearr[$j]["cell".$i]["h"] !== '1') {$tmpTD=$tmpTD.' rowspan='.$linearr[$j]["cell".$i]["h"];}
		$tmpTR=$tmpTR.$tmpTD.'>'.$linearr[$j]["cell".$i]["cnt"].$cell3;
	}
	$tmpTR=$tmpTR.$cell2;
}
echo $tmpTR;
?>