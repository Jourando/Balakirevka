// v.10.a.7::global revision
rd='sh_tab_xls_v';
urlStr='auth.php?';
datStr='writ2.php?';
logStr='actlog.php?';
depMod=0;
curMod=0;
var xth = new Array();
var yth = new Array();
xth[0]=10;
xth[1]='номер';
xth[2]='отделение';
xth[3]='дата';
xth[4]='вид деятельности';
xth[5]='мероприятие';
xth[6]='место проведения';
xth[7]='охват';
xth[8]='организация';
xth[9]='орг-фин';
xth[10]='доп.инфо';
yth[0]=13;
yth[1]='начало';
yth[2]='конец';
yth[3]='форма работы';
yth[4]='наше/совместное/иное';
yth[5]='название';
yth[6]='уровень';
yth[7]='ЦА';
yth[8]='зрители';
yth[9]='выступающие/участники'
yth[10]='ОП';
yth[11]='руководитель';
yth[12]='ответственный';
yth[13]='орг';
var esize = new Array();
esize[0]=5;
esize[1]=6;
esize[2]=6;
esize[3]=6;
esize[4]=8;
esize[5]=8;
esize[6]=8;
esize[7]=8;
esize[8]=8;
esize[9]=6;
esize[10]=6;
esize[11]=5;
esize[12]=5;
esize[13]=6;
esize[14]=6;
esize[15]=6;
esize[16]=6;
esize[17]=8;
esize[18]=8;
function thNames() {
var ths=document.getElementsByTagName('th').length;
for (ix=0; ix<ths; ix++) {
		if (ix<10) {
			document.getElementsByTagName('th')[ix].innerHTML=xth[ix+1];
		} else if ((ix>9) && (ix<23)) {
			document.getElementsByTagName('th')[ix].innerHTML=yth[ix-9];
		}
}
}