<?php
$linelimit=19;
$deplimit=12;
?>